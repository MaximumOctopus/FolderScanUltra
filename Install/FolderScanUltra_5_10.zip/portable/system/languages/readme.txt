 Language Information File :: August 8th 2023
=============================================

Hello,

Thanks for looking! :)

If you're thinking of translating the text then please make sure you use the versions from the "UK" folder.

If you need any further help or information then please don't hesitate to email me;

    paul@freshney.org

    There are five files to translate which represent the majority of content:
        language.txt
	units.txt

Many Thanks,

Paul